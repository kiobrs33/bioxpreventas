<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-3">
            <div class="alert alert-info" role="alert">
                Lista de todos los Clientes registrados!.
            </div>

            <!-- div que mostrara los errores de validacion del formulario -->
            <?php if(count($errors)): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

        </div>

        <div class="col-sm-6">

            <div class="card">
                <div class="card-header text-center">
                    <b>Editar Cliente</b>
                </div>
                <form action="<?php echo e(route('clientes.update')); ?>" method="POST">

                    <?php echo e(csrf_field()); ?>


                    <input type="hidden" name="id_cliente" value="<?php echo e($cliente->id); ?>">

                    <div class="card-body">

                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Nombres</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="nombres_cliente"
                                    value="<?php echo e($cliente->nombres); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Apellidos</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="apellidos_cliente"
                                    value="<?php echo e($cliente->apellidos); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Dni</label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control" name="dni_cliente" value="<?php echo e($cliente->dni); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Telefono</label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control" name="telefono_cliente"
                                    value="<?php echo e($cliente->telefono); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Ruc</label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control" name="ruc_cliente" value="<?php echo e($cliente->ruc); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Empresa</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="empresa_cliente"
                                    value="<?php echo e($cliente->empresa); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3 ">Direccion Empresa</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="direccion_empresa_cliente"
                                    value="<?php echo e($cliente->direccion_empresa); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3 ">Direccion Pedido</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="direccion_pedido_cliente"
                                    value="<?php echo e($cliente->direccion_pedido); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="row justify-content-md-center">
                            <div class="col-sm-3">
                                <button type="submit" class="btn btn-success btn-block">Guardar</button>
                            </div>
                            <div class="col-sm-3">
                                <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-danger btn-block">Volver</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>