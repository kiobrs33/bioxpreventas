<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-3">
            <div class="alert alert-info" role="alert">
                Actualizar Bono!
            </div>

            <!-- div que mostrara los errores de validacion del formulario -->
            <?php if(count($errors)): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

        </div>

        <div class="col-sm-6">

            <div class="card">
                <div class="card-header text-center">
                    <b>Nuevo Bono</b>
                </div>
                <form action="<?php echo e(route('bonos.update')); ?>" method="POST">

                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" value="<?php echo e($bono->id); ?>" name="id_bono">

                    <div class="card-body">

                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Titulo</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="titulo_bono" value="<?php echo e($bono->titulo); ?>">
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Descripcion</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" rows="2"
                                    name="descripcion_bono"><?php echo e($bono->descripcion); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Producto</label>
                            <div class="col-sm-6">
                                <select class="form-control" name="productsId_bono">
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($pro->id == $bono->products_id): ?>
                                    <option value="<?php echo e($pro->id); ?>" selected><?php echo e($pro->nombre); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->nombre); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Cantidad</label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control" name="cantidad_bono"
                                    value="<?php echo e($bono->cantidad_producto); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="row justify-content-md-center">
                            <div class="col-sm-3">
                                <button type="submit" class="btn btn-success btn-block" id="btn_guardarCliente">
                                    Guardar</button>
                            </div>
                            <div class="col-sm-3">
                                <a href="<?php echo e(route('bonos.index')); ?>" class="btn btn-danger btn-block">Volver</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>