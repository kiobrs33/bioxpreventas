<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-3">
            <div class="alert alert-info" role="alert">
                Ver Bono!
            </div>

            <!-- div que mostrara los errores de validacion del formulario -->
            <?php if(count($errors)): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

        </div>

        <div class="col-sm-6">

            <div class="card">
                <div class="card-header text-center">
                    <b>Ver Bono</b>
                </div>

                <div class="card-body">

                    <div class="form-group row justify-content-center">
                        <label class="col-sm-3">Titulo</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" value="<?php echo e($bono->titulo); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row justify-content-center">
                        <label class="col-sm-3">Descripcion</label>
                        <div class="col-sm-6">
                            <textarea class="form-control" rows="2" readonly><?php echo e($bono->descripcion); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row justify-content-center">
                        <label class="col-sm-3">Producto</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" value="<?php echo e($bono->nombre_producto); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row justify-content-center">
                        <label class="col-sm-3">Cantidad</label>
                        <div class="col-sm-6">
                            <input type="number" class="form-control" value="<?php echo e($bono->cantidad_producto); ?>" readonly>
                        </div>
                    </div>
                </div>

                <div class="card-footer">
                    <div class="row justify-content-md-center">
                        <div class="col-sm-3">
                            <a href="<?php echo e(route('bonos.index')); ?>" class="btn btn-danger btn-block">Volver</a>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>