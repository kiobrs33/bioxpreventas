<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-3">
            <div class="alert alert-info" role="alert">
                Mi INFORMACION!.
            </div>
        </div>

        <div class="col-sm-6">

            <div class="card">
                <div class="card-header text-center">
                    <b>Ver Empleado</b>
                </div>
                <form>

                    <div class="card-body">
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Nombres</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="nombres_empleado"
                                    value="<?php echo e($empleado->nombres); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Apellidos</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="apellidos_empleado"
                                    value="<?php echo e($empleado->apellidos); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Telefono</label>
                            <div class="col-sm-6">
                                <input type="number" class="form-control" name="telefono_empleado"
                                    value="<?php echo e($empleado->telefono); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <label class="col-sm-3">Correo</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="correo_empleado"
                                    value="<?php echo e($empleado->correo); ?>" readonly>
                            </div>
                        </div>

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>