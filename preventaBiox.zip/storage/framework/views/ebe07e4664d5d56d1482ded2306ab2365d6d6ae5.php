<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row justify-content-center">
        <div class="col-sm-3">
            <div class="alert alert-info" role="alert">
                <h5>BONOS</h5>
            </div>
        </div>
        <div class="col-sm-7">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Titulo</th>
                            <th>Descripcion</th>
                            <th>Cantidad Gratis</th>
                            <th>Producto</th>
                            <th width="100px">
                                <a href="<?php echo e(route('bonos.create')); ?>" class="btn btn-success btn-block">
                                    <i class="fas fa-plus-circle"></i>
                                </a>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($bono->id); ?></td>
                            <td><?php echo e($bono->titulo); ?></td>
                            <td><?php echo e($bono->descripcion); ?></td>
                            <td><?php echo e($bono->cantidad_producto); ?></td>
                            <td><?php echo e($bono->nombre_producto); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                                    <a href="<?php echo e(route('bonos.edit',$bono->slug)); ?>" class="btn btn-secondary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('bonos.show', $bono->slug)); ?>" class="btn btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($bonos->links("pagination::bootstrap-4")); ?>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>