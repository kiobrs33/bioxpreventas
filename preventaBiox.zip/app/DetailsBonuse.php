<?php

namespace preventaBiox;

use Illuminate\Database\Eloquent\Model;

class DetailsBonuse extends Model
{
    //
}
