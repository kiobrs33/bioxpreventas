<a href="{{route('pedidos.show',$slug)}}" class="btn btn-success btn-sm">
    <i class="fas fa-eye"></i>
</a>